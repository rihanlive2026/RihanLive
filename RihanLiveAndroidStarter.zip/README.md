# Rihan Live Android Starter

A starter Android app built with Kotlin and Jetpack Compose.

## Open and run
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Run on an Android emulator or connected phone.

This is a UI starter only. It does not include real authentication, live streaming, payments, backend, moderation, or production security.
