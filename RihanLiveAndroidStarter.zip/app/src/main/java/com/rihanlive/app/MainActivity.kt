package com.rihanlive.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class LiveRoom(val name: String, val viewers: String, val topic: String)

private val Purple = Color(0xFF8B5CF6)
private val DarkBg = Color(0xFF10111B)
private val CardBg = Color(0xFF202132)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RihanLiveApp() }
    }
}

@Composable
fun RihanLiveApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedRoom by remember { mutableStateOf<LiveRoom?>(null) }
    val rooms = remember {
        listOf(
            LiveRoom("Ayesha", "1.2K", "Welcome to my live ❤️"),
            LiveRoom("Sana", "856", "Let's chat together ✨"),
            LiveRoom("Rihan", "2.4K", "Rihan Live Official")
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = DarkBg, surface = CardBg)) {
        Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
            if (selectedRoom != null) {
                LiveRoomScreen(selectedRoom!!, onBack = { selectedRoom = null })
            } else {
                Scaffold(
                    containerColor = DarkBg,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF171827)) {
                            val labels = listOf("Home", "Live", "Messages", "Wallet", "Profile")
                            val icons = listOf(Icons.Default.Home, Icons.Default.Videocam, Icons.Default.Chat, Icons.Default.AccountBalanceWallet, Icons.Default.Person)
                            labels.forEachIndexed { index, label ->
                                NavigationBarItem(
                                    selected = selectedTab == index,
                                    onClick = { selectedTab = index },
                                    icon = { Icon(icons[index], contentDescription = label) },
                                    label = { Text(label, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Purple, selectedTextColor = Purple)
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding)) {
                        when (selectedTab) {
                            0 -> HomeScreen(rooms, onRoomClick = { selectedRoom = it })
                            1 -> LiveListScreen(rooms, onRoomClick = { selectedRoom = it })
                            2 -> SimplePage("Messages", "Private messaging will be added soon.")
                            3 -> SimplePage("Wallet", "Demo wallet — real payments are not active.")
                            4 -> ProfileScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(Purple, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Videocam, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Rihan Live", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Connect. Stream. Enjoy.", color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@Composable
fun HomeScreen(rooms: List<LiveRoom>, onRoomClick: (LiveRoom) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Header() }
        item { Text("Discover Live 🔥", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF38254C)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("● LIVE", color = Color(0xFFFF8A9A), fontWeight = FontWeight.Bold)
                        Text("1.2K watching", color = Color.White)
                    }
                    Spacer(Modifier.height(55.dp))
                    Text("Ayesha ❤️", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("Welcome to my live stream!", color = Color.LightGray)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { onRoomClick(rooms.first()) }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Text("Join Live")
                    }
                }
            }
        }
        item { Text("Live Rooms", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        items(rooms) { room -> RoomCard(room, onClick = { onRoomClick(room) }) }
    }
}

@Composable
fun LiveListScreen(rooms: List<LiveRoom>, onRoomClick: (LiveRoom) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Live Now 🔴", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        items(rooms) { room -> RoomCard(room, onClick = { onRoomClick(room) }) }
    }
}

@Composable
fun RoomCard(room: LiveRoom, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(66.dp).background(Color(0xFF45325D), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(room.name.take(1), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(room.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(room.topic, color = Color.LightGray)
                Text("${room.viewers} viewers", color = Color(0xFFC4B5FD), fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.LightGray)
        }
    }
}

@Composable
fun LiveRoomScreen(room: LiveRoom, onBack: () -> Unit) {
    var message by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("💜 Welcome to Rihan Live!", "👋 Say hello to everyone.")) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("Live Room", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF302042)), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("● LIVE  •  DEMO", color = Color(0xFFFF8A9A))
                Spacer(Modifier.height(35.dp))
                Box(Modifier.size(90.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Videocam, null, tint = Color.White, modifier = Modifier.size(48.dp))
                }
                Text(room.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Live video preview", color = Color.LightGray)
                Spacer(Modifier.height(30.dp))
                Text("👥 1,204 viewers", color = Color.White)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Live Chat", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        messages.forEach { Text(it, color = Color.LightGray, modifier = Modifier.padding(vertical = 5.dp)) }
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = message, onValueChange = { message = it }, modifier = Modifier.weight(1f), placeholder = { Text("Say something...") })
            IconButton(onClick = { if (message.isNotBlank()) { messages = messages + "You: $message"; message = "" } }) {
                Icon(Icons.Default.Send, null, tint = Purple)
            }
        }
        Text("Demo only: camera, broadcast and payments are not active.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("My Profile", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(100.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(58.dp))
        }
        Text("Rihan Khan", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("@rihanlive", color = Color.LightGray)
        Spacer(Modifier.height(24.dp))
        Text("Following   0        Followers   0", color = Color.White)
        Spacer(Modifier.height(30.dp))
        Text("Settings and privacy options will be added soon.", color = Color.LightGray)
    }
}

@Composable
fun SimplePage(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text(subtitle, color = Color.LightGray)
    }
}
